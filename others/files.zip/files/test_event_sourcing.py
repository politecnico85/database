import unittest
from unittest.mock import Mock
from datetime import date, datetime
from decimal import Decimal
from domain.aggregates.factura_aggregate import FacturaAggregate
from domain.aggregates.nota_credito_aggregate import NotaCreditoAggregate
from domain.entities.factura import Factura
from domain.entities.linea_factura import LineaFactura
from domain.entities.totales_factura import TotalesFactura
from domain.entities.nota_credito import NotaCredito
from domain.entities.linea_nota_credito import LineaNotaCredito
from domain.entities.totales_nota_credito import TotalesNotaCredito
from domain.entities.inventario import Inventario
from domain.value_objects.direccion import Direccion
from domain.value_objects.ruc import RUC
from domain.value_objects.forma_pago import FormaPago
from domain.value_objects.motivo_modificacion import MotivoModificacion
from domain.value_objects.precio import Precio
from domain.services.inventario_service import InventarioService
from domain.repositories.event_store import EventStore
from domain.events.factura_events import FacturaEmitida, StockReducido
from domain.events.nota_credito_events import NotaCreditoEmitida, StockIncrementado

class TestEventSourcing(unittest.TestCase):
    def setUp(self):
        self.direccion = Direccion("Calle Falsa 123", "Quito")
        self.ruc = RUC("1234567890001")
        self.forma_pago = FormaPago("Efectivo", Decimal('100.00'))
        self.inventario_service = Mock(spec=InventarioService)
        self.event_store = Mock(spec=EventStore)

    def test_factura_emission_generates_events(self):
        # Arrange
        factura = Factura(
            id_factura=1,
            id_sucursal=1,
            id_bodega=1,
            ruc_emisor=self.ruc,
            identificacion_adquiriente="0987654321",
            razon_social_emisor="Empresa XYZ",
            direccion_matriz=self.direccion,
            fecha_emision=date.today(),
            fecha_caducidad=date.today(),
            fecha_autorizacion=date.today(),
            forma_pago=self.forma_pago
        )
        totales = TotalesFactura(id_factura=1)
        aggregate = FacturaAggregate(factura, totales)
        linea = LineaFactura(
            id_producto=1,
            descripcion="Producto 1",
            cantidad=5,
            precio_unitario=Precio(Decimal('10.00'))
        )
        aggregate.agregar_linea(linea)
        self.inventario_service.obtener_inventarios_por_bodega.return_value = [
            Inventario(id_inventario=1, id_producto=1, id_bodega=1, cantidad_stock=10)
        ]

        # Act
        events = aggregate.emitir(self.inventario_service)

        # Assert
        self.assertEqual(len(events), 2)
        self.assertIsInstance(events[0], FacturaEmitida)
        self.assertIsInstance(events[1], StockReducido)
        self.assertEqual(events[0].aggregate_id, 1)
        self.assertEqual(events[1].data["producto_id"], 1)
        self.assertEqual(events[1].data["cantidad"], 5)

    def test_nota_credito_emission_generates_events(self):
        # Arrange
        nota_credito = NotaCredito(
            id_nota_credito=1,
            id_sucursal=1,
            ruc_emisor=self.ruc,
            id_factura_modificada=1,
            identificacion_adquiriente="0987654321",
            razon_social_emisor="Empresa XYZ",
            direccion_matriz=self.direccion,
            motivo_modificacion=MotivoModificacion("Devolución"),
            fecha_emision=date.today(),
            fecha_caducidad=date.today(),
            fecha_autorizacion=date.today()
        )
        totales = TotalesNotaCredito(id_nota_credito=1)
        aggregate = NotaCreditoAggregate(nota_credito, totales)
        linea = LineaNotaCredito(
            id_producto=1,
            descripcion="Devolución Producto 1",
            cantidad=2,
            valor_item_cobrado=Decimal('10.00')
        )
        aggregate.agregar_linea(linea)
        self.inventario_service.obtener_inventarios_por_bodega.return_value = [
            Inventario(id_inventario=1, id_producto=1, id_bodega=1, cantidad_stock=10)
        ]
        factura_agg = Mock()
        factura_agg.root.id_bodega = 1

        # Act
        events = aggregate.emitir(self.inventario_service, bodega_id=1, factura_agg=factura_agg)

        # Assert
        self.assertEqual(len(events), 2)
        self.assertIsInstance(events[0], NotaCreditoEmitida)
        self.assertIsInstance(events[1], StockIncrementado)
        self.assertEqual(events[0].aggregate_id, 1)
        self.assertEqual(events[1].data["producto_id"], 1)
        self.assertEqual(events[1].data["cantidad"], 2)

    def test_factura_reconstruction_from_events(self):
        # Arrange
        events = [
            FacturaEmitida(1, {
                "id_factura": 1,
                "id_sucursal": 1,
                "id_bodega": 1,
                "ruc_emisor": "1234567890001",
                "identificacion_adquiriente": "0987654321",
                "razon_social_emisor": "Empresa XYZ",
                "fecha_emision": date.today().isoformat()
            })
        ]

        # Act
        aggregate = FacturaAggregate.from_events(events)

        # Assert
        self.assertEqual(aggregate.root.id_factura, 1)
        self.assertEqual(aggregate.root.fecha_emision, date.today())

    def test_nota_credito_reconstruction_from_events(self):
        # Arrange
        events = [
            NotaCreditoEmitida(1, {
                "id_nota_credito": 1,
                "id_sucursal": 1,
                "id_factura_modificada": 1,
                "fecha_emision": date.today().isoformat()
            })
        ]

        # Act
        aggregate = NotaCreditoAggregate.from_events(events)

        # Assert
        self.assertEqual(aggregate.root.id_nota_credito, 1)
        self.assertEqual(aggregate.root.fecha_emision, date.today())