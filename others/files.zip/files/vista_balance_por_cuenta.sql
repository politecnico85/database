
CREATE VIEW BalancePorCuenta AS
SELECT
    da.cuenta_contable,
    pc.nombre_cuenta,
    SUM(da.debe) AS total_debe,
    SUM(da.haber) AS total_haber,
    SUM(da.debe) - SUM(da.haber) AS saldo
FROM
    DetalleAsiento da
JOIN
    PlanCuentas pc ON da.cuenta_contable = pc.codigo_cuenta
GROUP BY
    da.cuenta_contable, pc.nombre_cuenta;
