from typing import List, Optional
from domain.entities.inventario import Inventario

class InventarioRepository:
    def __init__(self):
        # In-memory store for simplicity (replace with actual DB)
        self._inventarios = {}

    def guardar(self, inventario: Inventario) -> None:
        """Save or update an inventory record."""
        self._inventarios[(inventario.id_bodega, inventario.id_producto)] = inventario

    def obtener_por_bodega_y_producto(self, id_bodega: int, id_producto: int) -> Optional[Inventario]:
        """Retrieve inventory by warehouse and product."""
        return self._inventarios.get((id_bodega, id_producto))

    def obtener_inventarios_por_bodega(self, id_bodega: int) -> List[Inventario]:
        """Retrieve all inventories for a warehouse."""
        return [inv for (bodega, _), inv in self._inventarios.items() if bodega == id_bodega]