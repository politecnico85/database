from typing import Optional, List
from domain.aggregates.factura_aggregate import FacturaAggregate
from domain.events.domain_event import DomainEvent
from domain.repositories.event_store import EventStore
from infrastructure.persistence.snapshot_sql import SnapshotRepository

class FacturaRepository:
    def __init__(self, event_store: EventStore, snapshot_repository: SnapshotRepository):
        self.event_store = event_store
        self.snapshot_repository = snapshot_repository

    def guardar(self, aggregate: FacturaAggregate) -> None:
        """Save the aggregate's pending events and snapshot."""
        events = aggregate.get_pending_events()
        if not events:
            return

        # Save events to event store
        for event in events:
            self.event_store.append(event)

        # Save snapshot every N events (e.g., 10)
        if len(events) >= 10 or aggregate._version % 10 == 0:
            snapshot = aggregate.to_snapshot()
            self.snapshot_repository.save_snapshot(
                aggregate_id=aggregate.root.id_factura,
                aggregate_type="Factura",
                snapshot_data=snapshot,
                version=aggregate._version
            )

        aggregate.clear_pending_events()

    def obtener_por_id(self, id_factura: int) -> Optional[FacturaAggregate]:
        """Retrieve an aggregate by ID, using snapshot if available."""
        snapshot = self.snapshot_repository.get_latest_snapshot(id_factura, "Factura")
        events = self.event_store.get_events(id_factura, "Factura", snapshot_version=snapshot.get("version", 0) if snapshot else 0)

        if not snapshot and not events:
            return None

        # Reconstruct aggregate from snapshot and events
        return FacturaAggregate.from_snapshot(snapshot or {}, events)