from abc import ABC, abstractmethod
from domain.entities.producto import Producto

class ProductoRepository(ABC):
    @abstractmethod
    def obtener_por_id(self, id: int) -> Producto:
        pass