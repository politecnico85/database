from domain.events.domain_event import DomainEvent
from domain.services.inventario_service import InventarioService
from infrastructure.persistence.projection_sql import ProjectionRepository
from decimal import Decimal

class EventHandler:
    def __init__(self, inventario_service: InventarioService, projection_repository: ProjectionRepository):
        self.inventario_service = inventario_service
        self.projection_repository = projection_repository

    def handle(self, event: DomainEvent):
        if event.event_type == "StockReducido":
            self.inventario_service.registrar_salida_fifo(
                producto_id=event.data["producto_id"],
                bodega_id=event.data["bodega_id"],
                cantidad=event.data["cantidad"],
                factura_id=event.aggregate_id
            )
            current_stock = self.projection_repository.get_stock(
                event.data["producto_id"], event.data["bodega_id"]
            )
            new_stock = max(0.0, current_stock - event.data["cantidad"])
            self.projection_repository.update_stock(
                event.data["producto_id"], event.data["bodega_id"], new_stock
            )
        elif event.event_type == "StockIncrementado":
            self.inventario_service.registrar_entrada(
                producto_id=event.data["producto_id"],
                bodega_id=event.data["bodega_id"],
                cantidad=event.data["cantidad"],
                costo_unitario=Decimal(event.data["costo_unitario"]),
                nota_credito_id=event.aggregate_id
            )
            current_stock = self.projection_repository.get_stock(
                event.data["producto_id"], event.data["bodega_id"]
            )
            new_stock = current_stock + event.data["cantidad"]
            self.projection_repository.update_stock(
                event.data["producto_id"], event.data["bodega_id"], new_stock
            )
        elif event.event_type == "FacturaEmitida":
            self.projection_repository.save_factura(event.data)
        elif event.event_type == "NotaCreditoEmitida":
            self.projection_repository.save_nota_credito(event.data)