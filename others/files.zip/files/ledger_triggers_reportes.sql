
-- Vista materializada del Ledger
CREATE TABLE Ledger (
    ledger_id SERIAL PRIMARY KEY,
    account_id INT REFERENCES Account(account_id),
    date DATE,
    total_debit NUMERIC(18,2),
    total_credit NUMERIC(18,2)
);

-- Trigger para actualizar Ledger al insertar JournalLine
CREATE OR REPLACE FUNCTION update_ledger_on_insert() RETURNS TRIGGER AS $$
BEGIN
    -- Verificar si ya existe un registro para la cuenta y fecha
    IF EXISTS (
        SELECT 1 FROM Ledger
        WHERE account_id = NEW.account_id AND date = (SELECT date FROM JournalEntry WHERE journal_entry_id = NEW.journal_entry_id)
    ) THEN
        -- Actualizar registro existente
        UPDATE Ledger
        SET total_debit = total_debit + COALESCE(NEW.debit, 0),
            total_credit = total_credit + COALESCE(NEW.credit, 0)
        WHERE account_id = NEW.account_id AND date = (SELECT date FROM JournalEntry WHERE journal_entry_id = NEW.journal_entry_id);
    ELSE
        -- Insertar nuevo registro
        INSERT INTO Ledger (account_id, date, total_debit, total_credit)
        VALUES (
            NEW.account_id,
            (SELECT date FROM JournalEntry WHERE journal_entry_id = NEW.journal_entry_id),
            COALESCE(NEW.debit, 0),
            COALESCE(NEW.credit, 0)
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Asociar trigger a JournalLine
CREATE TRIGGER trg_update_ledger
AFTER INSERT ON JournalLine
FOR EACH ROW
EXECUTE FUNCTION update_ledger_on_insert();

-- Estructura base para reporte contable: Balance de comprobación
CREATE VIEW TrialBalance AS
SELECT
    a.account_id,
    a.name AS account_name,
    SUM(l.total_debit) AS total_debit,
    SUM(l.total_credit) AS total_credit,
    SUM(l.total_debit - l.total_credit) AS balance
FROM Ledger l
JOIN Account a ON a.account_id = l.account_id
GROUP BY a.account_id, a.name;
