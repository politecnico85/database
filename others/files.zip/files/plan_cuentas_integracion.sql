
-- Tabla de Plan de Cuentas
CREATE TABLE PlanCuentas (
  codigo_cuenta VARCHAR(20) PRIMARY KEY,
  nombre_cuenta VARCHAR(100) NOT NULL,
  tipo_cuenta ENUM('ACTIVO', 'PASIVO', 'PATRIMONIO', 'INGRESO', 'GASTO') NOT NULL,
  nivel INT NOT NULL,
  cuenta_padre VARCHAR(20),
  FOREIGN KEY (cuenta_padre) REFERENCES PlanCuentas(codigo_cuenta) ON DELETE SET NULL
);

-- Tabla de Reglas Contables
CREATE TABLE ReglasContables (
  id_regla INT AUTO_INCREMENT PRIMARY KEY,
  tipo_documento VARCHAR(50) NOT NULL,
  cuenta_debe VARCHAR(20) NOT NULL,
  cuenta_haber VARCHAR(20) NOT NULL,
  FOREIGN KEY (cuenta_debe) REFERENCES PlanCuentas(codigo_cuenta),
  FOREIGN KEY (cuenta_haber) REFERENCES PlanCuentas(codigo_cuenta)
);

-- Modificación de DetalleAsiento para vincular con PlanCuentas
ALTER TABLE DetalleAsiento
ADD CONSTRAINT fk_detalleasiento_cuenta FOREIGN KEY (cuenta_contable)
REFERENCES PlanCuentas(codigo_cuenta) ON DELETE RESTRICT;

-- Procedimiento para generar asiento desde factura
DELIMITER //
CREATE PROCEDURE GenerarAsientoDesdeFactura(IN factura_id INT, IN total_factura DECIMAL(10,2), IN usuario_id INT)
BEGIN
  DECLARE asiento_id INT;
  DECLARE cuenta_debe VARCHAR(20);
  DECLARE cuenta_haber VARCHAR(20);

  -- Crear asiento contable
  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURRENT_DATE, CONCAT('Asiento desde factura ', factura_id), 'FACTURA', factura_id, usuario_id);
  SET asiento_id = LAST_INSERT_ID();

  -- Obtener cuentas desde reglas contables
  SELECT cuenta_debe, cuenta_haber
  INTO cuenta_debe, cuenta_haber
  FROM ReglasContables
  WHERE tipo_documento = 'FACTURA'
  LIMIT 1;

  -- Insertar detalle debe
  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_debe, 'Cuenta por cobrar', total_factura, 0);

  -- Insertar detalle haber
  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_haber, 'Ingreso por ventas', 0, total_factura);
END;
//
DELIMITER ;

-- Procedimiento para generar asiento desde nota de crédito
DELIMITER //
CREATE PROCEDURE GenerarAsientoDesdeNotaCredito(IN nota_id INT, IN total_nota DECIMAL(10,2), IN usuario_id INT)
BEGIN
  DECLARE asiento_id INT;
  DECLARE cuenta_debe VARCHAR(20);
  DECLARE cuenta_haber VARCHAR(20);

  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURRENT_DATE, CONCAT('Asiento desde nota de crédito ', nota_id), 'NOTA_CREDITO', nota_id, usuario_id);
  SET asiento_id = LAST_INSERT_ID();

  SELECT cuenta_debe, cuenta_haber
  INTO cuenta_debe, cuenta_haber
  FROM ReglasContables
  WHERE tipo_documento = 'NOTA_CREDITO'
  LIMIT 1;

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_debe, 'Devolución de ingreso', total_nota, 0);

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_haber, 'Reducción de cuentas por cobrar', 0, total_nota);
END;
//
DELIMITER ;

-- Procedimiento para generar asiento desde orden de compra
DELIMITER //
CREATE PROCEDURE GenerarAsientoDesdeOrdenCompra(IN orden_id INT, IN total_orden DECIMAL(10,2), IN usuario_id INT)
BEGIN
  DECLARE asiento_id INT;
  DECLARE cuenta_debe VARCHAR(20);
  DECLARE cuenta_haber VARCHAR(20);

  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURRENT_DATE, CONCAT('Asiento desde orden de compra ', orden_id), 'ORDEN_COMPRA', orden_id, usuario_id);
  SET asiento_id = LAST_INSERT_ID();

  SELECT cuenta_debe, cuenta_haber
  INTO cuenta_debe, cuenta_haber
  FROM ReglasContables
  WHERE tipo_documento = 'ORDEN_COMPRA'
  LIMIT 1;

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_debe, 'Inventario recibido', total_orden, 0);

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (asiento_id, cuenta_haber, 'Cuenta por pagar', 0, total_orden);
END;
//
DELIMITER ;
