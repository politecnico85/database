
CREATE VIEW ProfitLossReport AS
SELECT
    a.account_id,
    a.name AS account_name,
    a.type,
    SUM(l.total_debit) AS total_debit,
    SUM(l.total_credit) AS total_credit,
    CASE
        WHEN a.type = 'Revenue' THEN SUM(l.total_credit - l.total_debit)
        WHEN a.type = 'Expense' THEN SUM(l.total_debit - l.total_credit)
        ELSE 0
    END AS net_amount
FROM Ledger l
JOIN Account a ON a.account_id = l.account_id
WHERE a.type IN ('Revenue', 'Expense')
GROUP BY a.account_id, a.name, a.type;
