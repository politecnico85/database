from typing import List
   from domain.entities.factura import Factura
   from domain.entities.linea_factura import LineaFactura
   from domain.entities.totales_factura import TotalesFactura
   from domain.services.inventario_service import InventarioService
   from domain.specifications.factura_specifications import (
       FacturaTieneLineas, FacturaTotalValido, FormaPagoValida, FechaEmisionValida, 
       FechaCaducidadValida, FechaAutorizacionValida
   )
   from domain.specifications.inventario_specifications import StockSuficienteParaFactura
   from domain.events.factura_events import FacturaEmitida, StockReducido
   from domain.events.domain_event import DomainEvent
   from domain.value_objects.ruc import RUC
   from datetime import date

   class FacturaAggregate:
       def __init__(self, factura: Factura, totales: TotalesFactura):
           self.root = factura
           self.root.totales = totales
           self._validaciones = [
               FacturaTieneLineas(),
               FacturaTotalValido(),
               FormaPagoValida(),
               FechaEmisionValida(),
               FechaCaducidadValida(),
               FechaAutorizacionValida()
           ]
           self._events: List[DomainEvent] = []

       def agregar_linea(self, linea: LineaFactura):
           self.root.agregar_linea(linea)
           self._verificar_invariantes()

       def emitir(self, inventario_service: InventarioService) -> List[DomainEvent]:
           inventarios = inventario_service.obtener_inventarios_por_bodega(self.root.id_bodega)
           if not StockSuficienteParaFactura(inventarios, self.root.id_bodega).is_satisfied_by(self.root):
               raise ValueError("Stock insuficiente para emitir la factura.")
           self._verificar_invariantes()
           
           # Emit events
           factura_data = {
               "id_factura": self.root.id_factura,
               "id_sucursal": self.root.id_sucursal,
               "id_bodega": self.root.id_bodega,
               "ruc_emisor": str(self.root.ruc_emisor),
               "identificacion_adquiriente": self.root.identificacion_adquiriente,
               "razon_social_emisor": self.root.razon_social_emisor,
               "fecha_emision": self.root.fecha_emision.isoformat()
           }
           self._events.append(FacturaEmitida(self.root.id_factura, factura_data))
           
           for linea in self.root.lineas:
               self._events.append(StockReducido(
                   self.root.id_factura,
                   linea.id_producto,
                   self.root.id_bodega,
                   linea.cantidad,
                   float(linea.precio_unitario.valor)
               ))
           return self._events

       def _verificar_invariantes(self):
           errors = []
           for spec in self._validaciones:
               if not spec.is_satisfied_by(self.root):
                   errors.append(f"Validación fallida: {spec.__class__.__name__}")
           if errors:
               raise ValueError("; ".join(errors))

       def apply_event(self, event: DomainEvent):
           if event.event_type == "FacturaEmitida":
               self.root.id_factura = event.data["id_factura"]
               self.root.fecha_emision = date.fromisoformat(event.data["fecha_emision"])
           # Add more event types as needed

       @classmethod
       def from_events(cls, events: List[DomainEvent]) -> 'FacturaAggregate':
           factura = Factura(id_sucursal=0, id_bodega=0, ruc_emisor=RUC(""), 
                           identificacion_adquiriente="", razon_social_emisor="", 
                           direccion_matriz=None, fecha_emision=date.today(), 
                           fecha_caducidad=None, fecha_autorizacion=date.today(), 
                           forma_pago=None)
           totales = TotalesFactura(id_factura=0)
           aggregate = cls(factura, totales)
           for event in events:
               aggregate.apply_event(event)
           return aggregate

       @classmethod
       def crear_nueva(cls, id_sucursal: int, id_bodega: int, ruc_emisor: str, adquiriente: str, 
                       direccion: 'Direccion', razon_social: str, forma_pago: 'FormaPago', 
                       fecha_emision: date = None, fecha_caducidad: date = None, 
                       fecha_autorizacion: date = None):
           factura = Factura(
               id_sucursal=id_sucursal,
               id_bodega=id_bodega,
               ruc_emisor=RUC(ruc_emisor),
               identificacion_adquiriente=adquiriente,
               razon_social_emisor=razon_social,
               direccion_matriz=direccion,
               fecha_emision=fecha_emision or date.today(),
               fecha_caducidad=fecha_caducidad,
               fecha_autorizacion=fecha_autorizacion or date.today(),
               forma_pago=forma_pago
           )
           totales = TotalesFactura(id_factura=0)
           aggregate = cls(factura, totales)
           aggregate._verificar_invariantes()
           return aggregate