
-- ============================================
-- MODELO DE FACTURACIÓN, INVENTARIO Y CONTABILIDAD
-- ============================================

-- CLIENTES
CREATE TABLE Clientes (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  identificacion VARCHAR(13) NOT NULL UNIQUE,
  nombre_comercial VARCHAR(100),
  razon_social VARCHAR(100),
  direccion VARCHAR(200),
  telefono VARCHAR(20),
  email VARCHAR(100),
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- USUARIOS
CREATE TABLE Usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(50) NOT NULL UNIQUE,
  contraseña_hash VARCHAR(255) NOT NULL,
  nombre_completo VARCHAR(100),
  email VARCHAR(100),
  activo BOOLEAN DEFAULT TRUE,
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ROLES Y PERMISOS
CREATE TABLE Roles (
  id_rol INT AUTO_INCREMENT PRIMARY KEY,
  nombre_rol VARCHAR(50) NOT NULL UNIQUE,
  descripcion TEXT
);

CREATE TABLE Permisos (
  id_permiso INT AUTO_INCREMENT PRIMARY KEY,
  nombre_permiso VARCHAR(50) NOT NULL UNIQUE,
  descripcion TEXT
);

CREATE TABLE UsuarioRol (
  id_usuario INT NOT NULL,
  id_rol INT NOT NULL,
  PRIMARY KEY (id_usuario, id_rol),
  FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_rol) REFERENCES Roles(id_rol) ON DELETE CASCADE
);

CREATE TABLE RolPermiso (
  id_rol INT NOT NULL,
  id_permiso INT NOT NULL,
  PRIMARY KEY (id_rol, id_permiso),
  FOREIGN KEY (id_rol) REFERENCES Roles(id_rol) ON DELETE CASCADE,
  FOREIGN KEY (id_permiso) REFERENCES Permisos(id_permiso) ON DELETE CASCADE
);

-- PLAN DE CUENTAS
CREATE TABLE PlanCuentas (
  codigo_cuenta VARCHAR(20) PRIMARY KEY,
  nombre_cuenta VARCHAR(100) NOT NULL,
  tipo_cuenta ENUM('ACTIVO', 'PASIVO', 'PATRIMONIO', 'INGRESO', 'GASTO') NOT NULL,
  nivel INT NOT NULL,
  cuenta_padre VARCHAR(20),
  FOREIGN KEY (cuenta_padre) REFERENCES PlanCuentas(codigo_cuenta) ON DELETE SET NULL
);

-- REGLAS CONTABLES
CREATE TABLE ReglasContables (
  id_regla INT AUTO_INCREMENT PRIMARY KEY,
  tipo_documento VARCHAR(50),
  cuenta_debe VARCHAR(20),
  cuenta_haber VARCHAR(20),
  FOREIGN KEY (cuenta_debe) REFERENCES PlanCuentas(codigo_cuenta),
  FOREIGN KEY (cuenta_haber) REFERENCES PlanCuentas(codigo_cuenta)
);

-- TIPOS DE MOVIMIENTO
CREATE TABLE TiposMovimiento (
  id_tipo_movimiento INT AUTO_INCREMENT PRIMARY KEY,
  nombre_tipo VARCHAR(20) NOT NULL UNIQUE
);

-- ASIENTOS CONTABLES
CREATE TABLE AsientosContables (
  id_asiento INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE NOT NULL,
  descripcion TEXT,
  origen VARCHAR(50),
  id_origen INT,
  creado_por INT,
  FOREIGN KEY (creado_por) REFERENCES Usuarios(id_usuario) ON DELETE SET NULL
);

CREATE TABLE DetalleAsiento (
  id_detalle INT AUTO_INCREMENT PRIMARY KEY,
  id_asiento INT NOT NULL,
  cuenta_contable VARCHAR(20) NOT NULL,
  descripcion TEXT,
  debe DECIMAL(10,2) DEFAULT 0,
  haber DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (id_asiento) REFERENCES AsientosContables(id_asiento) ON DELETE CASCADE,
  FOREIGN KEY (cuenta_contable) REFERENCES PlanCuentas(codigo_cuenta) ON DELETE RESTRICT
);

-- VISTA DE BALANCE POR CUENTA
CREATE VIEW BalancePorCuenta AS
SELECT
  pc.codigo_cuenta,
  pc.nombre_cuenta,
  SUM(COALESCE(da.debe, 0)) AS total_debe,
  SUM(COALESCE(da.haber, 0)) AS total_haber,
  SUM(COALESCE(da.debe, 0)) - SUM(COALESCE(da.haber, 0)) AS saldo
FROM PlanCuentas pc
LEFT JOIN DetalleAsiento da ON pc.codigo_cuenta = da.cuenta_contable
GROUP BY pc.codigo_cuenta, pc.nombre_cuenta;
