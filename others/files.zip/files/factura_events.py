from domain.events.domain_event import DomainEvent

class FacturaEmitida(DomainEvent):
    def __init__(self, aggregate_id: int, data: dict, event_version: int = 1):
        super().__init__(aggregate_id, "Factura", "FacturaEmitida", data, event_version=event_version)

class StockReducido(DomainEvent):
    def __init__(self, aggregate_id: int, producto_id: int, bodega_id: int, cantidad: float, 
                 costo_unitario: float, event_version: int = 1):
        data = {
            "producto_id": producto_id,
            "bodega_id": bodega_id,
            "cantidad": cantidad,
            "costo_unitario": costo_unitario
        }
        super().__init__(aggregate_id, "Factura", "StockReducido", data, event_version=event_version)