
CREATE TABLE PlanCuentas (
  codigo_cuenta VARCHAR(20) PRIMARY KEY,
  nombre_cuenta VARCHAR(100) NOT NULL,
  tipo_cuenta ENUM('ACTIVO', 'PASIVO', 'PATRIMONIO', 'INGRESO', 'GASTO') NOT NULL,
  nivel INT NOT NULL,
  cuenta_padre VARCHAR(20),
  FOREIGN KEY (cuenta_padre) REFERENCES PlanCuentas(codigo_cuenta) ON DELETE SET NULL
);

-- Activo
INSERT INTO PlanCuentas VALUES ('1', 'ACTIVO', 'ACTIVO', 1, NULL);
INSERT INTO PlanCuentas VALUES ('1.1', 'Activo Corriente', 'ACTIVO', 2, '1');
INSERT INTO PlanCuentas VALUES ('1.1.01', 'Caja', 'ACTIVO', 3, '1.1');
INSERT INTO PlanCuentas VALUES ('1.1.02', 'Bancos', 'ACTIVO', 3, '1.1');
INSERT INTO PlanCuentas VALUES ('1.1.03', 'Cuentas por cobrar clientes', 'ACTIVO', 3, '1.1');
INSERT INTO PlanCuentas VALUES ('1.1.04', 'Inventario de mercadería', 'ACTIVO', 3, '1.1');
INSERT INTO PlanCuentas VALUES ('1.2', 'Activo No Corriente', 'ACTIVO', 2, '1');
INSERT INTO PlanCuentas VALUES ('1.2.01', 'Propiedades, planta y equipo', 'ACTIVO', 3, '1.2');

-- Pasivo
INSERT INTO PlanCuentas VALUES ('2', 'PASIVO', 'PASIVO', 1, NULL);
INSERT INTO PlanCuentas VALUES ('2.1', 'Pasivo Corriente', 'PASIVO', 2, '2');
INSERT INTO PlanCuentas VALUES ('2.1.01', 'Cuentas por pagar proveedores', 'PASIVO', 3, '2.1');
INSERT INTO PlanCuentas VALUES ('2.1.02', 'Obligaciones bancarias corto plazo', 'PASIVO', 3, '2.1');
INSERT INTO PlanCuentas VALUES ('2.2', 'Pasivo No Corriente', 'PASIVO', 2, '2');
INSERT INTO PlanCuentas VALUES ('2.2.01', 'Obligaciones bancarias largo plazo', 'PASIVO', 3, '2.2');

-- Patrimonio
INSERT INTO PlanCuentas VALUES ('3', 'PATRIMONIO', 'PATRIMONIO', 1, NULL);
INSERT INTO PlanCuentas VALUES ('3.1', 'Capital social', 'PATRIMONIO', 2, '3');
INSERT INTO PlanCuentas VALUES ('3.2', 'Utilidades retenidas', 'PATRIMONIO', 2, '3');

-- Ingreso
INSERT INTO PlanCuentas VALUES ('4', 'INGRESO', 'INGRESO', 1, NULL);
INSERT INTO PlanCuentas VALUES ('4.1', 'Ventas de mercadería', 'INGRESO', 2, '4');
INSERT INTO PlanCuentas VALUES ('4.2', 'Descuentos concedidos', 'INGRESO', 2, '4');

-- Gasto
INSERT INTO PlanCuentas VALUES ('5', 'GASTO', 'GASTO', 1, NULL);
INSERT INTO PlanCuentas VALUES ('5.1', 'Costo de ventas', 'GASTO', 2, '5');
INSERT INTO PlanCuentas VALUES ('5.2', 'Gastos administrativos', 'GASTO', 2, '5');
INSERT INTO PlanCuentas VALUES ('5.3', 'Gastos de ventas', 'GASTO', 2, '5');
INSERT INTO PlanCuentas VALUES ('5.4', 'Gastos financieros', 'GASTO', 2, '5');
