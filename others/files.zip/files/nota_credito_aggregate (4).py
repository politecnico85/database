from typing import List
   from domain.entities.nota_credito import NotaCredito
   from domain.entities.linea_nota_credito import LineaNotaCredito
   from domain.entities.totales_nota_credito import TotalesNotaCredito
   from domain.services.inventario_service import InventarioService
   from domain.specifications.nota_credito_specifications import (
       NotaCreditoTieneLineas, NotaCreditoTotalValido, MotivoModificacionValido,
       FechaEmisionValida, FechaCaducidadValida, FechaAutorizacionValida,
       InventarioExisteParaNotaCredito
   )
   from domain.events.nota_credito_events import NotaCreditoEmitida, StockIncrementado
   from domain.events.domain_event import DomainEvent
   from domain.value_objects.ruc import RUC
   from domain.value_objects.motivo_modificacion import MotivoModificacion
   from datetime import date

   class NotaCreditoAggregate:
       def __init__(self, nota_credito: NotaCredito, totales: TotalesNotaCredito):
           self.root = nota_credito
           self.root.totales = totales
           self._validaciones = [
               NotaCreditoTieneLineas(),
               NotaCreditoTotalValido(),
               MotivoModificacionValido(),
               FechaEmisionValida(),
               FechaCaducidadValida(),
               FechaAutorizacionValida()
           ]
           self._events: List[DomainEvent] = []

       def agregar_linea(self, linea: LineaNotaCredito):
           self.root.agregar_linea(linea)
           self._verificar_invariantes()

       def emitir(self, inventario_service: InventarioService, bodega_id: int, factura_agg: 'FacturaAggregate') -> List[DomainEvent]:
           inventarios = inventario_service.obtener_inventarios_por_bodega(bodega_id)
           if not InventarioExisteParaNotaCredito(inventarios, bodega_id).is_satisfied_by(self.root):
               raise ValueError("Inventario no encontrado para los productos en la bodega especificada.")
           self._verificar_invariantes()
           
           # Emit events
           nota_credito_data = {
               "id_nota_credito": self.root.id_nota_credito,
               "id_sucursal": self.root.id_sucursal,
               "id_factura_modificada": self.root.id_factura_modificada,
               "fecha_emision": self.root.fecha_emision.isoformat()
           }
           self._events.append(NotaCreditoEmitida(self.root.id_nota_credito, nota_credito_data))
           
           for linea in self.root.lineas:
               self._events.append(StockIncrementado(
                   self.root.id_nota_credito,
                   linea.id_producto,
                   bodega_id,
                   linea.cantidad,
                   float(linea.valor_item_cobrado)
               ))
           return self._events

       def _verificar_invariantes(self):
           errors = []
           for spec in self._validaciones:
               if not spec.is_satisfied_by(self.root):
                   errors.append(f"Validación fallida: {spec.__class__.__name__}")
           if errors:
               raise ValueError("; ".join(errors))

       def apply_event(self, event: DomainEvent):
           if event.event_type == "NotaCreditoEmitida":
               self.root.id_nota_credito = event.data["id_nota_credito"]
               self.root.fecha_emision = date.fromisoformat(event.data["fecha_emision"])
           # Add more event types as needed

       @classmethod
       def from_events(cls, events: List[DomainEvent]) -> 'NotaCreditoAggregate':
           nota_credito = NotaCredito(
               id_sucursal=0,
               ruc_emisor=RUC(""),
               id_factura_modificada=0,
               identificacion_adquiriente="",
               razon_social_emisor="",
               direccion_matriz=None,
               motivo_modificacion=None,
               fecha_emision=date.today(),
               fecha_caducidad=None,
               fecha_autorizacion=date.today()
           )
           totales = TotalesNotaCredito(id_nota_credito=0)
           aggregate = cls(nota_credito, totales)
           for event in events:
               aggregate.apply_event(event)
           return aggregate

       @classmethod
       def crear_nueva(cls, id_sucursal: int, ruc_emisor: str, id_factura_modificada: int, adquiriente: str, 
                       direccion: 'Direccion', razon_social: str, motivo: str, 
                       fecha_emision: date = None, fecha_caducidad: date = None, fecha_autorizacion: date = None):
           nota_credito = NotaCredito(
               id_sucursal=id_sucursal,
               ruc_emisor=RUC(ruc_emisor),
               id_factura_modificada=id_factura_modificada,
               identificacion_adquiriente=adquiriente,
               razon_social_emisor=razon_social,
               direccion_matriz=direccion,
               motivo_modificacion=MotivoModificacion(motivo),
               fecha_emision=fecha_emision or date.today(),
               fecha_caducidad=fecha_caducidad,
               fecha_autorizacion=fecha_autorizacion or date.today()
           )
           totales = TotalesNotaCredito(id_nota_credito=0)
           aggregate = cls(nota_credito, totales)
           aggregate._verificar_invariantes()
           return aggregate