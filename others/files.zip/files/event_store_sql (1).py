from sqlalchemy import Column, Integer, String, JSON, DateTime, create_engine
   from sqlalchemy.ext.declarative import declarative_base
   from sqlalchemy.orm import sessionmaker
   from domain.repositories.event_store import EventStore
   from domain.events.domain_event import DomainEvent
   from typing import List

   Base = declarative_base()

   class EventRecord(Base):
       __tablename__ = 'events'
       id = Column(Integer, primary_key=True)
       event_id = Column(String, unique=True)
       aggregate_id = Column(Integer, index=True)
       event_type = Column(String)
       data = Column(JSON)
       occurred_on = Column(DateTime)

   class SqlEventStore(EventStore):
       def __init__(self, database_url: str):
           self.engine = create_engine(database_url)
           Base.metadata.create_all(self.engine)
           self.Session = sessionmaker(bind=self.engine)

       def append(self, event: DomainEvent):
           session = self.Session()
           try:
               event_record = EventRecord(
                   event_id=event.event_id,
                   aggregate_id=event.aggregate_id,
                   event_type=event.event_type,
                   data=event.data,
                   occurred_on=event.occurred_on
               )
               session.add(event_record)
               session.commit()
           finally:
               session.close()

       def get_events(self, aggregate_id: int) -> List[DomainEvent]:
           session = self.Session()
           try:
               records = session.query(EventRecord).filter_by(aggregate_id=aggregate_id).order_by(EventRecord.occurred_on).all()
               return [DomainEvent(record.aggregate_id, record.event_type, record.data, record.occurred_on) 
                       for record in records]
           finally:
               session.close()