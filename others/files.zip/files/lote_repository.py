from typing import List, Optional
from domain.entities.lote import Lote
from datetime import date

class LoteRepository:
    def __init__(self):
        # In-memory store for simplicity (replace with actual DB)
        self._lotes = {}

    def guardar(self, lote: Lote) -> None:
        """Save or update a lot."""
        self._lotes[(lote.id_bodega, lote.id_producto, lote.id_lote)] = lote

    def obtener_por_bodega_y_producto(self, id_bodega: int, id_producto: int) -> List[Lote]:
        """Retrieve lots by warehouse and product, sorted by entry date (FIFO)."""
        lotes = [lote for (bodega, prod, _), lote in self._lotes.items() 
                 if bodega == id_bodega and prod == id_producto]
        return sorted(lotes, key=lambda x: x.fecha_entrada)

    def obtener_por_id(self, id_bodega: int, id_producto: int, id_lote: int) -> Optional[Lote]:
        """Retrieve a specific lot by ID."""
        return self._lotes.get((id_bodega, id_producto, id_lote))