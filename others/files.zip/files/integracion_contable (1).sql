
-- ============================================
-- INTEGRACIÓN CONTABLE CON FACTURACIÓN E INVENTARIO
-- ============================================

-- Tabla de Asientos Contables
CREATE TABLE IF NOT EXISTS AsientosContables (
  id_asiento INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE NOT NULL,
  descripcion TEXT,
  origen VARCHAR(50), -- Ej: 'FACTURA', 'NOTA_CREDITO', 'ORDEN_COMPRA'
  id_origen INT,       -- ID del documento origen
  creado_por INT,
  FOREIGN KEY (creado_por) REFERENCES Usuarios(id_usuario) ON DELETE SET NULL
);

-- Detalle de cada asiento contable
CREATE TABLE IF NOT EXISTS DetalleAsiento (
  id_detalle INT AUTO_INCREMENT PRIMARY KEY,
  id_asiento INT NOT NULL,
  cuenta_contable VARCHAR(20) NOT NULL,
  descripcion TEXT,
  debe DECIMAL(10,2) DEFAULT 0,
  haber DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (id_asiento) REFERENCES AsientosContables(id_asiento) ON DELETE CASCADE
);

-- Procedimiento para generar asiento contable desde una factura
DELIMITER $$

CREATE PROCEDURE GenerarAsientoDesdeFactura(IN factura_id INT, IN usuario_id INT)
BEGIN
  DECLARE total_factura DECIMAL(10,2);
  DECLARE descripcion_factura TEXT;

  SELECT total INTO total_factura FROM TotalesFactura WHERE id_factura = factura_id;
  SELECT CONCAT('Asiento generado desde factura #', factura_id) INTO descripcion_factura;

  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURDATE(), descripcion_factura, 'FACTURA', factura_id, usuario_id);

  SET @asiento_id = LAST_INSERT_ID();

  -- Asiento contable: Venta
  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '1101', 'Cuenta por cobrar cliente', total_factura, 0);

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '4101', 'Ingreso por ventas', 0, total_factura);
END$$

-- Procedimiento para generar asiento contable desde una nota de crédito
CREATE PROCEDURE GenerarAsientoDesdeNotaCredito(IN nota_id INT, IN usuario_id INT)
BEGIN
  DECLARE total_nota DECIMAL(10,2);
  DECLARE descripcion_nota TEXT;

  SELECT total INTO total_nota FROM TotalesNotaCredito WHERE id_nota_credito = nota_id;
  SELECT CONCAT('Asiento generado desde nota de crédito #', nota_id) INTO descripcion_nota;

  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURDATE(), descripcion_nota, 'NOTA_CREDITO', nota_id, usuario_id);

  SET @asiento_id = LAST_INSERT_ID();

  -- Asiento contable: Devolución
  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '4101', 'Reverso ingreso por ventas', total_nota, 0);

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '1101', 'Reverso cuenta por cobrar cliente', 0, total_nota);
END$$

-- Procedimiento para generar asiento contable desde una orden de compra
CREATE PROCEDURE GenerarAsientoDesdeOrdenCompra(IN orden_id INT, IN usuario_id INT)
BEGIN
  DECLARE total_orden DECIMAL(10,2);
  DECLARE descripcion_orden TEXT;

  SELECT total INTO total_orden FROM TotalesOrdenCompra WHERE id_orden_compra = orden_id;
  SELECT CONCAT('Asiento generado desde orden de compra #', orden_id) INTO descripcion_orden;

  INSERT INTO AsientosContables (fecha, descripcion, origen, id_origen, creado_por)
  VALUES (CURDATE(), descripcion_orden, 'ORDEN_COMPRA', orden_id, usuario_id);

  SET @asiento_id = LAST_INSERT_ID();

  -- Asiento contable: Compra
  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '5101', 'Gasto por compras', total_orden, 0);

  INSERT INTO DetalleAsiento (id_asiento, cuenta_contable, descripcion, debe, haber)
  VALUES (@asiento_id, '2101', 'Cuenta por pagar proveedor', 0, total_orden);
END$$

DELIMITER ;
