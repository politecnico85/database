
-- Tabla de monedas
CREATE TABLE Currency (
    currency_id SERIAL PRIMARY KEY,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(50),
    exchange_rate_to_base NUMERIC(18,6)
);

-- Tabla de cuentas contables
CREATE TABLE Account (
    account_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(50),
    currency_id INT REFERENCES Currency(currency_id),
    parent_account_id INT REFERENCES Account(account_id),
    is_active BOOLEAN DEFAULT TRUE
);

-- Asientos contables
CREATE TABLE JournalEntry (
    journal_entry_id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    description TEXT,
    module VARCHAR(50)
);

-- Líneas de asiento contable
CREATE TABLE JournalLine (
    journal_line_id SERIAL PRIMARY KEY,
    journal_entry_id INT REFERENCES JournalEntry(journal_entry_id),
    account_id INT REFERENCES Account(account_id),
    debit NUMERIC(18,2),
    credit NUMERIC(18,2),
    currency_id INT REFERENCES Currency(currency_id),
    amount_original NUMERIC(18,2),
    amount_base NUMERIC(18,2)
);

-- Clientes
CREATE TABLE Customer (
    customer_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    tax_id VARCHAR(50),
    payment_terms VARCHAR(50),
    currency_id INT REFERENCES Currency(currency_id)
);

-- Proveedores
CREATE TABLE Vendor (
    vendor_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    tax_id VARCHAR(50),
    payment_terms VARCHAR(50),
    currency_id INT REFERENCES Currency(currency_id)
);

-- Facturas por cobrar
CREATE TABLE InvoiceAR (
    invoice_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES Customer(customer_id),
    date DATE,
    due_date DATE,
    amount NUMERIC(18,2),
    currency_id INT REFERENCES Currency(currency_id),
    status VARCHAR(20)
);

-- Pagos recibidos
CREATE TABLE PaymentAR (
    payment_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES Customer(customer_id),
    invoice_id INT REFERENCES InvoiceAR(invoice_id),
    date DATE,
    amount NUMERIC(18,2),
    currency_id INT REFERENCES Currency(currency_id),
    exchange_rate NUMERIC(18,6),
    journal_entry_id INT REFERENCES JournalEntry(journal_entry_id)
);

-- Facturas por pagar
CREATE TABLE InvoiceAP (
    invoice_id SERIAL PRIMARY KEY,
    vendor_id INT REFERENCES Vendor(vendor_id),
    date DATE,
    due_date DATE,
    amount NUMERIC(18,2),
    currency_id INT REFERENCES Currency(currency_id),
    status VARCHAR(20)
);

-- Pagos realizados
CREATE TABLE PaymentAP (
    payment_id SERIAL PRIMARY KEY,
    vendor_id INT REFERENCES Vendor(vendor_id),
    invoice_id INT REFERENCES InvoiceAP(invoice_id),
    date DATE,
    amount NUMERIC(18,2),
    currency_id INT REFERENCES Currency(currency_id),
    exchange_rate NUMERIC(18,6),
    journal_entry_id INT REFERENCES JournalEntry(journal_entry_id)
);

-- Activos fijos
CREATE TABLE Asset (
    asset_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    acquisition_date DATE,
    cost NUMERIC(18,2),
    useful_life INT,
    depreciation_method VARCHAR(50),
    account_id INT REFERENCES Account(account_id)
);

-- Inventario
CREATE TABLE InventoryItem (
    item_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    quantity NUMERIC(18,2),
    unit_cost NUMERIC(18,2),
    account_id INT REFERENCES Account(account_id)
);

-- Instrumentos de deuda
CREATE TABLE DebtInstrument (
    debt_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    issue_date DATE,
    maturity_date DATE,
    principal NUMERIC(18,2),
    interest_rate NUMERIC(5,2),
    account_id INT REFERENCES Account(account_id)
);

-- Ingresos diferidos
CREATE TABLE DeferredRevenue (
    revenue_id SERIAL PRIMARY KEY,
    description TEXT,
    start_date DATE,
    end_date DATE,
    total_amount NUMERIC(18,2),
    account_id INT REFERENCES Account(account_id)
);
