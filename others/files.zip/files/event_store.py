from abc import ABC, abstractmethod
   from typing import List
   from domain.events.domain_event import DomainEvent

   class EventStore(ABC):
       @abstractmethod
       def append(self, event: DomainEvent):
           pass

       @abstractmethod
       def get_events(self, aggregate_id: int) -> List[DomainEvent]:
           pass