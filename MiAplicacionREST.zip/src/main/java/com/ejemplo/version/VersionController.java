package com.ejemplo.version;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
public class VersionController {

    @GetMapping("/version")
    public VersionInfo getVersion() {
        return new VersionInfo(
            "MiAplicacionREST",
            "1.0.0",
            LocalDate.now().toString()
        );
    }
}
