package com.ejemplo.version;

public class VersionInfo {
    private String nombre;
    private String version;
    private String fecha;

    public VersionInfo(String nombre, String version, String fecha) {
        this.nombre = nombre;
        this.version = version;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public String getVersion() {
        return version;
    }

    public String getFecha() {
        return fecha;
    }
}
